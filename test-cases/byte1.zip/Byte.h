#ifndef BYTE_H
#define BYTE_H

#include <vector>
#include <string>

class Byte {
private:
    std::vector<int> bits;
    void setValue(int value);

public:
    Byte();
    Byte(int value);

    int toInt() const;
    std::string toString() const;

    Byte operator+(const Byte& other) const;
    Byte operator-(const Byte& other) const;
    Byte operator*(const Byte& other) const;
    Byte operator/(const Byte& other) const;

    bool operator==(const Byte& other) const;
    bool operator!=(const Byte& other) const;
};

#endif
