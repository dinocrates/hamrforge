#include "Byte.h"
#include <algorithm>
#include <stdexcept>

Byte::Byte() {
    setValue(0);
}

Byte::Byte(int value) {
    setValue(value);
}

void Byte::setValue(int value) {
    if (value < 0) {
        value = 0;
    }

    // Keep this Byte class in the unsigned 8-bit range.
    value = value % 256;

    bits.assign(8, 0);

    for (int i = 7; i >= 0; --i) {
        bits[i] = value % 2;
        value /= 2;
    }
}

int Byte::toInt() const {
    int value = 0;

    for (int bit : bits) {
        value = value * 2 + bit;
    }

    return value;
}

std::string Byte::toString() const {
    std::string result;

    for (int bit : bits) {
        result += bit ? '1' : '0';
    }

    return result;
}

Byte Byte::operator+(const Byte& other) const {
    return Byte(this->toInt() + other.toInt());
}

Byte Byte::operator-(const Byte& other) const {
    return Byte(this->toInt() - other.toInt());
}

Byte Byte::operator*(const Byte& other) const {
    return Byte(this->toInt() * other.toInt());
}

Byte Byte::operator/(const Byte& other) const {
    if (other.toInt() == 0) {
        throw std::runtime_error("Division by zero");
    }

    return Byte(this->toInt() / other.toInt());
}

bool Byte::operator==(const Byte& other) const {
    return this->toInt() == other.toInt();
}

bool Byte::operator!=(const Byte& other) const {
    return !(*this == other);
}
