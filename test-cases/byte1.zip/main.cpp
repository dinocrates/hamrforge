#include <iostream>
#include "Byte.h"

int main() {
    Byte a(5);
    Byte b(7);
    Byte c = a + b;

    std::cout << "a: " << a.toInt() << " (" << a.toString() << ")" << std::endl;
    std::cout << "b: " << b.toInt() << " (" << b.toString() << ")" << std::endl;
    std::cout << "c: " << c.toInt() << " (" << c.toString() << ")" << std::endl;

    return 0;
}
