#include "Byte.h"

int main() {
    Byte b;
    b.setValue(13);
    return b.toInt();
}
