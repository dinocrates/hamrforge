#include <iostream>
#include "Byte.hpp"

int main() {
    std::cout << "This submission is intentionally incomplete." << std::endl;
    return 0;
}
