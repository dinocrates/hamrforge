// Intentionally wrong filename for HamrForge checkpoint 2 testing.
// The assignment requires Byte.h and Byte.cpp, so this should fail file_check.
class Byte {
public:
    Byte() {}
};
